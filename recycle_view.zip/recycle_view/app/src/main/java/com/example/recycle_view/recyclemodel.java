package com.example.recycle_view;

public class recyclemodel {
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public recyclemodel(String name){
        this.name= name;

    }
}
